# Social-Media-Sentiment-Analysis-Using-Machine-Learning
A Machine Learning Model to analyse the nature of tweets and classify them as Positive/Negative


### This is a Mini-Project as assigned by Graphic Era University.